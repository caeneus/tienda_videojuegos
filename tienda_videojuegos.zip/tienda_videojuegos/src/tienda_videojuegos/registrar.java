/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tienda_videojuegos;

import conexiones.conexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Miguel
 */
public class registrar extends javax.swing.JFrame {

    /**
     * Creates new form registrar
     */
    public registrar() {
        initComponents();
        setLocationRelativeTo(null);
    }
//en esta funcion se declaran todas las sentencias y restricciones que se tendran en cuanta a la hora de registrar el usuario
    public void registrar() {

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        PreparedStatement ps2 = null;
        ResultSet rs2 = null;

        String user = nombreUsuario.getText();
        String pass = textContraseña.getText();
        String passRep = textContraseñaRepetida.getText();
        String nombre = nombre1.getText();
        String apellidos = apellidos1.getText();
        String email = correo.getText();
        String codigo = adminCode.getText();
        String codigoAdmin = "admin";
        String codigoUser = "user";

        if (user.equals("") || pass.equals("") || nombre.equals("") || apellidos.equals("")) {
            JOptionPane.showMessageDialog(this, "Uno o mas campos estan vacios.Rellenelos");
        } else {
            try {

                con = conexionBD.conectar();
                ps = con.prepareStatement("select nombre_usuario from usuarios where nombre_usuario='" + user + "'   ");
                rs = ps.executeQuery();
                ps2 = con.prepareStatement("select email from usuarios where email='" + email + "'   ");
                rs2 = ps2.executeQuery();

                if (rs.next()) {
                    JOptionPane.showMessageDialog(this, "El nombre de usuario ya existe.Introduce uno nuevo.");
                } else {
                    if (rs2.next()) {
                        JOptionPane.showMessageDialog(this, "Existe un usuario registrado con este correo.Introduce un nuevo email.");
                    } else {
                        if (pass.equals(passRep)) {
                            if (codigo.equals("")) {
                                ps = con.prepareStatement("insert into usuarios (nombre,apellidos,email,nombre_usuario,contraseña,rol_user) values (?,?,?,?,?,?)");
                                ps.setString(1, nombre);
                                ps.setString(2, apellidos);
                                ps.setString(3, email);
                                ps.setString(4, user);
                                ps.setString(5, pass);
                                ps.setString(6, codigoUser);
                                ps.execute();
                                JOptionPane.showMessageDialog(this, "Usuario registrado con exito.");
                                loginFinal inicio = new loginFinal();
                                inicio.setVisible(true);
                                this.dispose();

                            } else if (codigo.equals("1234")) {
                                ps = con.prepareStatement("insert into usuarios (nombre,apellidos,email,nombre_usuario,contraseña,rol_user) values (?,?,?,?,?,?)");
                                ps.setString(1, nombre);
                                ps.setString(2, apellidos);
                                ps.setString(3, email);
                                ps.setString(4, user);
                                ps.setString(5, pass);
                                ps.setString(6, codigoAdmin);
                                ps.execute();
                                JOptionPane.showMessageDialog(this, "Usuario Administrador registrado con exito.");
                                loginFinal inicio = new loginFinal();
                                inicio.setVisible(true);
                                this.dispose();

                            } else {
                                JOptionPane.showMessageDialog(this, "Codigo administrador incorrecto.Introduzcalo de nuevo o cree un user normal");
                            }
                        }else{
                            JOptionPane.showMessageDialog(this, "Las contraseñas son distintas,Introduce de nuevo la contraseña");
                        }
                    }
                }

            } catch (SQLException e) {
                System.err.print(e.toString());
                JOptionPane.showMessageDialog(this, "Ocurrio un error inesperado.");
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        apellidos1 = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        nombre1 = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        correo = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        nombreUsuario = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        adminCode = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jSeparator7 = new javax.swing.JSeparator();
        volver = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        registrar1 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jSeparator8 = new javax.swing.JSeparator();
        textContraseña = new javax.swing.JPasswordField();
        textContraseñaRepetida = new javax.swing.JPasswordField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAlwaysOnTop(true);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        apellidos1.setFont(new java.awt.Font("Segoe UI Historic", 0, 18)); // NOI18N
        apellidos1.setBorder(null);
        apellidos1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apellidos1ActionPerformed(evt);
            }
        });
        jPanel3.add(apellidos1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 380, 454, 40));
        jPanel3.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 420, 460, 10));

        jLabel3.setBackground(new java.awt.Color(102, 102, 102));
        jLabel3.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        jLabel3.setText("Apellidos:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 350, 90, 30));

        nombre1.setFont(new java.awt.Font("Segoe UI Historic", 0, 18)); // NOI18N
        nombre1.setBorder(null);
        nombre1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombre1ActionPerformed(evt);
            }
        });
        jPanel3.add(nombre1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, 454, 40));
        jPanel3.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 340, 460, 10));

        jLabel4.setBackground(new java.awt.Color(102, 102, 102));
        jLabel4.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        jLabel4.setText("Nombre:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 270, 90, 30));

        correo.setFont(new java.awt.Font("Segoe UI Historic", 0, 18)); // NOI18N
        correo.setBorder(null);
        correo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                correoActionPerformed(evt);
            }
        });
        jPanel3.add(correo, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 460, 454, 40));

        jLabel5.setBackground(new java.awt.Color(102, 102, 102));
        jLabel5.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        jLabel5.setText("Email:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 430, 90, 30));
        jPanel3.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 500, 460, 10));

        jLabel6.setBackground(new java.awt.Color(102, 102, 102));
        jLabel6.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        jLabel6.setText("Contraseña:");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 100, 30));
        jPanel3.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 180, 460, 10));

        nombreUsuario.setFont(new java.awt.Font("Segoe UI Historic", 0, 18)); // NOI18N
        nombreUsuario.setBorder(null);
        nombreUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreUsuarioActionPerformed(evt);
            }
        });
        jPanel3.add(nombreUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, 454, 40));

        jLabel7.setBackground(new java.awt.Color(102, 102, 102));
        jLabel7.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        jLabel7.setText("Usuario:");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 30, 90, 30));
        jPanel3.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 460, 10));

        adminCode.setFont(new java.awt.Font("Segoe UI Historic", 0, 18)); // NOI18N
        adminCode.setBorder(null);
        adminCode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminCodeActionPerformed(evt);
            }
        });
        jPanel3.add(adminCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 550, 454, 40));

        jLabel8.setBackground(new java.awt.Color(102, 102, 102));
        jLabel8.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        jLabel8.setText("Cod. Admin:");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 510, 120, 30));
        jPanel3.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 590, 460, 10));

        volver.setBackground(new java.awt.Color(102, 0, 255));
        volver.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        volver.setForeground(new java.awt.Color(255, 255, 255));
        volver.setText("Volver");
        volver.setBorder(null);
        volver.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volverActionPerformed(evt);
            }
        });
        jPanel3.add(volver, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 630, 250, 40));

        jLabel2.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("x");
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 0, 40, 40));

        jLabel11.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        jLabel11.setText("(Opcional)");
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 510, 80, 40));

        registrar1.setBackground(new java.awt.Color(102, 0, 255));
        registrar1.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        registrar1.setForeground(new java.awt.Color(255, 255, 255));
        registrar1.setText("Registrar");
        registrar1.setBorder(null);
        registrar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        registrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrar1ActionPerformed(evt);
            }
        });
        jPanel3.add(registrar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 630, 250, 40));

        jLabel12.setBackground(new java.awt.Color(102, 102, 102));
        jLabel12.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        jLabel12.setText("Repetir Contraseña:");
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 190, 170, 30));
        jPanel3.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 260, 460, 10));

        textContraseña.setBorder(null);
        jPanel3.add(textContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 460, 40));

        textContraseñaRepetida.setBorder(null);
        jPanel3.add(textContraseñaRepetida, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 220, 460, 40));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 0, 660, 700));

        jLabel9.setFont(new java.awt.Font("Viner Hand ITC", 3, 48)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Comienza la ...");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 350, 120));

        jLabel10.setFont(new java.awt.Font("Viner Hand ITC", 3, 48)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("...Aventura");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 220, 290, 70));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/games-art-purple-background-video-games-purple-vertical-hd-wallpaper-preview.jpg"))); // NOI18N
        jLabel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jLabel1MouseDragged(evt);
            }
        });
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel1MousePressed(evt);
            }
        });
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-4, 0, 440, 700));

        pack();
    }// </editor-fold>//GEN-END:initComponents
int xx, xy;
    private void jLabel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();

        this.setLocation(x - xx, y - xy);
    }//GEN-LAST:event_jLabel1MouseDragged

    private void jLabel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MousePressed
        xx = evt.getX();
        xy = evt.getY();
    }//GEN-LAST:event_jLabel1MousePressed

    private void apellidos1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apellidos1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apellidos1ActionPerformed

    private void nombre1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombre1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombre1ActionPerformed

    private void correoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_correoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_correoActionPerformed

    private void nombreUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombreUsuarioActionPerformed

    private void adminCodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminCodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adminCodeActionPerformed

    private void volverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volverActionPerformed
        loginFinal inicio = new loginFinal();
        inicio.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_volverActionPerformed

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void registrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrar1ActionPerformed
        registrar();
    }//GEN-LAST:event_registrar1ActionPerformed

    /**
     * @param args the command line arguments
     */
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField adminCode;
    private javax.swing.JTextField apellidos1;
    private javax.swing.JTextField correo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JTextField nombre1;
    private javax.swing.JTextField nombreUsuario;
    private javax.swing.JButton registrar1;
    private javax.swing.JPasswordField textContraseña;
    private javax.swing.JPasswordField textContraseñaRepetida;
    private javax.swing.JButton volver;
    // End of variables declaration//GEN-END:variables
}
