/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexiones;


import java.sql.*;



/**
 *
 * @author AlumnoDam17
 */
public class conexionBD {
static Connection con = null;
    
    //public static String usuario = "miguel1";
  
    //public static String contraseña ="1234";
   

    public static Connection conectar() {
        
        
        String url = "jdbc:mysql://sql780.main-hosting.eu/u351916951_Tienda_online";
        String usuario ="u351916951_root";
        String contraseña = "Migue_12";
       
        
        try {

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, usuario, contraseña);
            

        } catch (Exception e) {

            System.out.println(e);
            
       
        
        }
        return con;
        }
    
    public void desconectar(){
        con = null;
    }
    }


