/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Administrador;

import java.util.Scanner;

/**
 *
 * @author AlumnoDam10
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        AdmMenu menuAdmin = new AdmMenu();
        UserMenu menuUsuario = new UserMenu();
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Inserte la opción que desea arrancar: ");
        System.out.println(" Opción 1: Administrador");
        System.out.println(" Opción 2: Usuario");
        int opcion = sc.nextInt();
        
        if (opcion == 1)
            menuAdmin.setVisible(true);
        if (opcion == 2)
            menuUsuario.setVisible(true);
        else
            System.out.println("Opción incorrecta");
    }
    
}
